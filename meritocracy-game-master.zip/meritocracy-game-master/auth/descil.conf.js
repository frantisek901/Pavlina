module.exports = {
	file: __dirname + "/auth_codes.js",
	uri: "AAA",
	project: "AAA",
	key: "AAA",
};
