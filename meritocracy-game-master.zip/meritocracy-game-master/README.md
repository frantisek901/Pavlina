# Meritocracy Game for nodeGame

Public-good game with noisy assortitative matching of high contributors for nodeGame.

## Rules

Description of a [Public-Good Game](https://en.wikipedia.org/wiki/Public_goods_game).

## Installation

Place this folder in the `games/` directory of your nodeGame installation.

For further information see [https://nodegame.org](https://nodegame.org).

## Version

nodeGame >= 4.0

## License

[MIT](LICENSE)
